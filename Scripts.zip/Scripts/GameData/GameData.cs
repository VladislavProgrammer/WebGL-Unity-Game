using UnityEngine;

public class GameData : MonoBehaviour
{
    public static int levelIndex;
    public static int score;
    public static int _currentWaweIndex;
    public static bool wawesComplete;
    public static int WeaponID;
    public static bool testBool;
    public static bool tutorialComplete;
    public static float BaseDamage;
    public static float speed;
    public static int currentSoliderCount;

}
























