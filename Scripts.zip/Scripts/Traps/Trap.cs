using UnityEngine;

public abstract class Trap : MonoBehaviour
{
    [SerializeField] protected float damage;

    
}
